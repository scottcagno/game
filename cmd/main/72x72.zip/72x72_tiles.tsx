<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="72x72_tiles" tilewidth="72" tileheight="72" tilecount="300" columns="6">
 <image source="72x72_tiles.png" trans="ff00ff" width="432" height="3600"/>
</tileset>
